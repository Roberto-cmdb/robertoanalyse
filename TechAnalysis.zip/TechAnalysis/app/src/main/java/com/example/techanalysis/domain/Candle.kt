package com.example.techanalysis.domain

data class Candle(
    val time: Long, // epoch seconds (UTC)
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
)
