package com.example.techanalysis.domain

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class DerivException(message: String) : Exception(message)

/**
 * Cotations Deriv via l'API WebSocket officielle (ticks_history, style "candles").
 * Les données de marché ne demandent aucun jeton : seul l'app_id est requis.
 * 1089 est l'identifiant public de test ; enregistrez le vôtre sur api.deriv.com pour la production.
 * Symboles : R_100 (indice synthétique), frxEURUSD (forex), cryBTCUSD (crypto), etc.
 */
class DerivQuoteProvider(
    private val appId: String = "1089",
    private val endpoint: String = "wss://ws.binaryws.com/websockets/v3",
    private val client: OkHttpClient = OkHttpClient(),
) : QuoteProvider {

    private fun wsRequest() = Request.Builder().url("$endpoint?app_id=$appId").build()

    private fun granularity(tf: Timeframe) = when (tf) {
        Timeframe.M1 -> 60
        Timeframe.M5 -> 300
        Timeframe.M15 -> 900
        Timeframe.H1 -> 3600
        Timeframe.D1 -> 86400
    }

    private fun body(symbol: String, tf: Timeframe, count: Int, subscribe: Boolean) = JSONObject()
        .put("ticks_history", symbol)
        .put("adjust_start_time", 1)
        .put("count", count)
        .put("end", "latest")
        .put("style", "candles")
        .put("granularity", granularity(tf))
        .apply { if (subscribe) put("subscribe", 1) }
        .toString()

    private fun errorOf(j: JSONObject): String? = j.optJSONObject("error")?.optString("message")

    override suspend fun history(symbol: String, timeframe: Timeframe, count: Int): List<Candle> =
        withTimeout(15_000) {
            suspendCancellableCoroutine { cont ->
                val ws = client.newWebSocket(wsRequest(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        webSocket.send(body(symbol, timeframe, count, subscribe = false))
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        val j = JSONObject(text)
                        val err = errorOf(j)
                        if (err != null) {
                            if (cont.isActive) cont.resumeWithException(DerivException(err))
                            webSocket.close(1000, null)
                            return
                        }
                        val arr = j.optJSONArray("candles") ?: return
                        val list = (0 until arr.length()).map { i ->
                            val c = arr.getJSONObject(i)
                            Candle(c.getLong("epoch"), c.getDouble("open"), c.getDouble("high"), c.getDouble("low"), c.getDouble("close"))
                        }
                        if (cont.isActive) cont.resume(list)
                        webSocket.close(1000, null)
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                })
                cont.invokeOnCancellation { ws.cancel() }
            }
        }

    /** Émet la bougie en cours à chaque mise à jour (messages « ohlc »). */
    override fun stream(symbol: String, timeframe: Timeframe): Flow<Candle> = callbackFlow {
        val ws = client.newWebSocket(wsRequest(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(body(symbol, timeframe, 1, subscribe = true))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val j = JSONObject(text)
                errorOf(j)?.let { close(DerivException(it)); return }
                j.optJSONObject("ohlc")?.let { o ->
                    trySend(Candle(o.getLong("open_time"), o.getDouble("open"), o.getDouble("high"), o.getDouble("low"), o.getDouble("close")))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { close(t) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { close() }
        })
        awaitClose { ws.cancel() }
    }
}
