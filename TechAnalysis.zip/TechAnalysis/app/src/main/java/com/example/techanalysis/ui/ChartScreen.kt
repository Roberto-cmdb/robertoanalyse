package com.example.techanalysis.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.techanalysis.domain.Analysis
import com.example.techanalysis.domain.Timeframe
import kotlin.math.abs
import kotlin.math.roundToInt

private object C {
    val bg = Color(0xFF10151B); val grid = Color(0xFF26303B)
    val text = Color(0xFFC9D3DD); val muted = Color(0xFF7A8896)
    val up = Color(0xFF3FB68B); val down = Color(0xFFE0674F)
    val sma = Color(0xFFE8B84A); val ema = Color(0xFF6FA8FF); val band = Color(0xFF8A94A3)
}

@Composable
fun ChartScreen(vm: ChartViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importCsv(displayName(ctx, it), ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText()) }
    }
    val a = s.analysis
    val n = a.candles.size

    MaterialTheme(colorScheme = darkColorScheme(background = C.bg, surface = C.bg, primary = C.sma)) {
        Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding()) {
            Header(s.symbol, a) { picker.launch(arrayOf("text/*", "application/csv", "application/octet-stream")) }
            s.error?.let { Text(it, color = C.down, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
            var symbolInput by remember { mutableStateOf("R_100") }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.source == DataSource.DEMO, onClick = { vm.load("DEMO", DataSource.DEMO) }, label = { Text("Démo") })
                FilterChip(selected = s.source == DataSource.DERIV, onClick = { vm.load(symbolInput, DataSource.DERIV) }, label = { Text("Deriv") })
                Timeframe.entries.forEach { tf ->
                    FilterChip(selected = s.timeframe == tf, onClick = { vm.load(tf = tf) }, label = { Text(tf.name) })
                }
            }
            if (s.source == DataSource.DERIV) {
                OutlinedTextField(
                    value = symbolInput, onValueChange = { symbolInput = it }, singleLine = true,
                    label = { Text("Symbole Deriv (ex. R_100, frxEURUSD)") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { vm.load(symbolInput, DataSource.DERIV) }),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
            if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Layer.entries.forEach { l ->
                    FilterChip(selected = l in s.layers, onClick = { vm.toggle(l) }, label = { Text(l.label) })
                }
            }
            if (n < 30) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Importez un fichier CSV pour afficher un graphique.", color = C.muted) }
                return@Column
            }

            var count by remember(n) { mutableFloatStateOf(90f) }
            var end by remember(n) { mutableFloatStateOf(n.toFloat()) }
            var widthPx by remember { mutableFloatStateOf(1f) }
            val from = (end - count).roundToInt().coerceAtLeast(0)
            val to = end.roundToInt().coerceAtMost(n)

            Column(
                Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp)
                    .onSizeChanged { widthPx = it.width.toFloat() }
                    .pointerInput(n) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val c = (count / zoom).coerceIn(20f, n.toFloat())
                            count = c
                            end = (end - pan.x / (widthPx / c)).coerceIn(c, n.toFloat())
                        }
                    }
            ) {
                PricePanel(a, s.layers, from, to, Modifier.weight(3f).fillMaxWidth())
                if (Layer.RSI in s.layers) RsiPanel(a, from, to, Modifier.weight(1f).fillMaxWidth())
                if (Layer.MACD in s.layers) MacdPanel(a, from, to, Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
private fun Header(symbol: String, a: Analysis, onImport: () -> Unit) {
    val last = a.candles.lastOrNull()
    val prev = a.candles.getOrNull(a.candles.size - 2)
    Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(symbol, color = C.text, fontSize = 20.sp)
            if (last != null && prev != null) {
                val ch = (last.close / prev.close - 1) * 100
                Text("%.2f  (%+.2f %%)".format(last.close, ch), color = if (ch >= 0) C.up else C.down, fontSize = 15.sp)
            }
        }
        OutlinedButton(onClick = onImport) { Text("Importer CSV") }
    }
}

// ---------- panneaux ----------

@Composable
private fun PricePanel(a: Analysis, layers: Set<Layer>, from: Int, to: Int, mod: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(mod) {
        val vis = a.candles.subList(from, to)
        var hi = vis.maxOf { it.high }; var lo = vis.minOf { it.low }
        if (Layer.BOLL in layers) {
            a.bands.upper.slice(from until to).filterNotNull().maxOrNull()?.let { hi = maxOf(hi, it) }
            a.bands.lower.slice(from until to).filterNotNull().minOrNull()?.let { lo = minOf(lo, it) }
        }
        val pad = (hi - lo) * 0.05; hi += pad; lo -= pad
        grid(4)
        val step = size.width / (to - from)
        vis.forEachIndexed { k, c ->
            val x = (k + 0.5f) * step
            val col = if (c.close >= c.open) C.up else C.down
            val yO = y(c.open, lo, hi); val yC = y(c.close, lo, hi)
            drawLine(col, Offset(x, y(c.high, lo, hi)), Offset(x, y(c.low, lo, hi)), 1.5f)
            drawRect(col, Offset(x - step * 0.35f, minOf(yO, yC)), Size(step * 0.7f, maxOf(abs(yO - yC), 1.5f)))
        }
        if (Layer.BOLL in layers) {
            line(a.bands.upper, from, to, lo, hi, C.band, 1.5f)
            line(a.bands.lower, from, to, lo, hi, C.band, 1.5f)
        }
        if (Layer.SMA in layers) line(a.sma20, from, to, lo, hi, C.sma)
        if (Layer.EMA in layers) line(a.ema50, from, to, lo, hi, C.ema)
        val st = TextStyle(color = C.muted, fontSize = 10.sp)
        drawText(tm, "%.2f".format(hi), Offset(6f, 2f), st)
        drawText(tm, "%.2f".format(lo), Offset(6f, size.height - 30f), st)
    }
}

@Composable
private fun RsiPanel(a: Analysis, from: Int, to: Int, mod: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(mod.padding(top = 6.dp)) {
        drawRect(C.grid.copy(alpha = 0.25f), Offset(0f, y(70.0, 0.0, 100.0)), Size(size.width, y(30.0, 0.0, 100.0) - y(70.0, 0.0, 100.0)))
        line(a.rsi, from, to, 0.0, 100.0, C.sma)
        val st = TextStyle(color = C.muted, fontSize = 10.sp)
        drawText(tm, "RSI 14   %.0f".format(a.rsi.getOrNull(to - 1) ?: 0.0), Offset(6f, 2f), st)
    }
}

@Composable
private fun MacdPanel(a: Analysis, from: Int, to: Int, mod: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(mod.padding(top = 6.dp)) {
        val m = a.macd
        val ext = (from until to).flatMap { listOf(m.line[it], m.signal[it], m.hist[it]) }.filterNotNull().maxOfOrNull { abs(it) } ?: 1.0
        val lo = -ext * 1.1; val hi = ext * 1.1
        drawLine(C.grid, Offset(0f, y(0.0, lo, hi)), Offset(size.width, y(0.0, lo, hi)), 1f)
        val step = size.width / (to - from)
        for (i in from until to) {
            val h = m.hist[i] ?: continue
            val x = (i - from + 0.5f) * step
            drawLine(if (h >= 0) C.up.copy(alpha = .6f) else C.down.copy(alpha = .6f), Offset(x, y(0.0, lo, hi)), Offset(x, y(h, lo, hi)), step * 0.6f)
        }
        line(m.line, from, to, lo, hi, C.ema)
        line(m.signal, from, to, lo, hi, C.sma)
        drawText(tm, "MACD 12·26·9", Offset(6f, 2f), TextStyle(color = C.muted, fontSize = 10.sp))
    }
}

// ---------- helpers de dessin ----------

private fun DrawScope.y(v: Double, lo: Double, hi: Double) = size.height * (1 - ((v - lo) / (hi - lo)).toFloat())

private fun DrawScope.grid(rows: Int) {
    for (i in 0..rows) drawLine(C.grid, Offset(0f, size.height * i / rows), Offset(size.width, size.height * i / rows), 1f)
}

private fun DrawScope.line(v: List<Double?>, from: Int, to: Int, lo: Double, hi: Double, color: Color, w: Float = 2.5f) {
    val step = size.width / (to - from)
    val p = Path(); var started = false
    for (i in from until to) {
        val value = v[i]
        if (value == null) { started = false; continue }
        val px = (i - from + 0.5f) * step; val py = y(value, lo, hi)
        if (!started) { p.moveTo(px, py); started = true } else p.lineTo(px, py)
    }
    drawPath(p, color, style = Stroke(w))
}

private fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i).substringBeforeLast('.') else null
    } ?: "CSV"
