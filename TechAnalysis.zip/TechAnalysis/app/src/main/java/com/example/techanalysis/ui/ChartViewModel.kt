package com.example.techanalysis.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.techanalysis.domain.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Layer(val label: String) { SMA("SMA 20"), EMA("EMA 50"), BOLL("Bollinger"), RSI("RSI"), MACD("MACD") }
enum class DataSource { DEMO, DERIV }

data class UiState(
    val symbol: String = "DEMO",
    val source: DataSource = DataSource.DEMO,
    val timeframe: Timeframe = Timeframe.D1,
    val analysis: Analysis = Analysis(emptyList()),
    val layers: Set<Layer> = Layer.entries.toSet() - Layer.BOLL,
    val loading: Boolean = false,
    val error: String? = null,
)

class ChartViewModel : ViewModel() {
    private val providers: Map<DataSource, QuoteProvider> = mapOf(
        DataSource.DEMO to SampleQuoteProvider(),
        DataSource.DERIV to DerivQuoteProvider(),
    )
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    init { load() }

    /** Charge l'historique puis suit la bougie en cours tant que l'écran est actif. */
    fun load(
        symbol: String = _state.value.symbol,
        source: DataSource = _state.value.source,
        tf: Timeframe = _state.value.timeframe,
    ) {
        job?.cancel()
        val sym = symbol.trim().ifEmpty { "DEMO" }
        _state.update { it.copy(symbol = sym, source = source, timeframe = tf, loading = true, error = null) }
        job = viewModelScope.launch {
            val p = providers.getValue(source)
            try {
                val history = p.history(sym, tf, 400)
                _state.update { it.copy(analysis = Analysis(history), loading = false) }
                p.stream(sym, tf).collect { c ->
                    _state.update { s ->
                        val list = s.analysis.candles.toMutableList()
                        when {
                            list.isEmpty() || c.time > list.last().time -> list += c
                            c.time == list.last().time -> list[list.lastIndex] = c
                            else -> return@update s
                        }
                        s.copy(analysis = Analysis(list))
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Connexion impossible") }
            }
        }
    }

    fun importCsv(name: String, text: String) {
        runCatching { Csv.parse(text) }
            .onSuccess { c ->
                job?.cancel()
                _state.update { it.copy(symbol = name, source = DataSource.DEMO, analysis = Analysis(c), loading = false, error = null) }
            }
            .onFailure { e -> _state.update { it.copy(error = e.message ?: "Fichier illisible") } }
    }

    fun toggle(layer: Layer) = _state.update {
        it.copy(layers = if (layer in it.layers) it.layers - layer else it.layers + layer)
    }
}
